// Importar los módulos necesarios
const express = require('express'); // Express: Framework para manejar el servidor
const path = require('path'); // Path: Módulo para trabajar con rutas de archivos

// Crear una aplicación Express
const app = express(); // Inicializamos la aplicación
const PORT = 3000; // Definimos el puerto donde se ejecutará el servidor

// Configurar middleware para servir archivos estáticos (CSS, imágenes, JavaScript, etc.)
// Archivos dentro de la carpeta 'public' estarán disponibles en el servidor
app.use(express.static('public'));

// ** Rutas **

// Ruta principal (página de inicio)
app.get('/', (req, res) => {
    // Enviar el archivo `index.html` como respuesta cuando el usuario accede a `/`
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Ruta "Acerca de" (página secundaria)
app.get('/about', (req, res) => {
    // Enviar el archivo `about.html` como respuesta cuando el usuario accede a `/about`
    res.sendFile(path.join(__dirname, 'views', 'about.html'));
});

// Manejo de rutas no existentes (404)
// Este middleware captura cualquier ruta no definida previamente
app.use((req, res) => {
    // Configurar el código de estado como 404 (No encontrado)
    res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

// ** Iniciar el servidor **
// Escuchar peticiones en el puerto definido
app.listen(PORT, () => {
    // Mostrar un mensaje en la consola indicando que el servidor está activo
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
